import Nav from "./components/Nav.jsx";
import Hero from "./components/Hero.jsx";
import Models from "./components/Models.jsx";
import Features from "./components/Features.jsx";
import Download from "./components/Download.jsx";
import Footer from "./components/Footer.jsx";

export default function App() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Models />
        <Features />
        <Download />
      </main>
      <Footer />
    </>
  );
}
